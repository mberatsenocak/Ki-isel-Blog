﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CvEntityProje
{
    public partial class Default : System.Web.UI.Page
    {

        DBCVENTITYEntities db = new DBCVENTITYEntities();

        protected void Page_Load (object sender, EventArgs e)
        {

            Repeater1.DataSource = db.HAKKINDAKISMI.ToList();
            Repeater1.DataBind();
            Repeater2.DataSource = db.HAKKINDAKISMI.ToList();
            Repeater2.DataBind();
            Repeater3.DataSource = db.HAKKINDAKISMI.ToList();
            Repeater3.DataBind();
            Repeater4.DataSource = db.TBLYETENEKLER.ToList();
            Repeater4.DataBind();
            Repeater5.DataSource = db.HAKKINDAKISMI.ToList();
            Repeater5.DataBind();
            Repeater6.DataSource = db.EGITIMINFO.ToList();
            Repeater6.DataBind();
            Repeater7.DataSource = db.EGITIMINFO.ToList();
            Repeater7.DataBind();
            Repeater8.DataSource = db.EGITIMINFO.ToList();
            Repeater8.DataBind();
            Repeater9.DataSource = db.EGITIMINFO.ToList();
            Repeater9.DataBind();
            Repeater10.DataSource = db.TBLILETISIM.ToList();
            Repeater10.DataBind();
            Repeater11.DataSource = db.TBLILETISIM.ToList();
            Repeater11.DataBind();
            Repeater12.DataSource = db.TBLILETISIM.ToList();
            Repeater12.DataBind();
            Repeater13.DataSource = db.TBLILETISIM.ToList();
            Repeater13.DataBind();
            Repeater14.DataSource = db.HAKKINDAKISMI.ToList();
            Repeater14.DataBind();
            Repeater15.DataSource = db.TBLSOSYALMEDYA.ToList();
            Repeater15.DataBind();
            Repeater16.DataSource = db.TBLSOSYALMEDYA.ToList();
            Repeater16.DataBind();


            
            {
                if (!IsPostBack)
                {
                    // Veritabanından verileri al
                    var yetenekler = db.TBLYETENEKLER.ToList();  // dbContext'iniz burada veritabanı bağlantısını yapar

                    // Repeater'a verileri bağla
                    Repeater4.DataSource = yetenekler;
                    Repeater4.DataBind();
                }
            }




            {
                if (!IsPostBack)
                {
                    // Veritabanından görsel yollarını çek
                    var images = db.CvImages.ToList();
                    RepeaterImages.DataSource = images;
                    RepeaterImages.DataBind();
                }
            }


        }

        protected void SubmitButton_Click(object sender, EventArgs e)
        {
            TBLILETISIM t = new TBLILETISIM();
            t.ADSOYAD = TextBoxName.Text;
            t.MAIL = TextBoxEmail.Text;
            t.KONU = TextBoxSubject.Text;
            t.MESAJ = TextBoxMessage.Text;
            db.TBLILETISIM.Add(t);
            db.SaveChanges();
        }


       
            
        }


    }
